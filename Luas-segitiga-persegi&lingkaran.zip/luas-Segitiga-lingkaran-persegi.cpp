#include <iostream>
using namespace std;

void luas_segitiga(); //Prototype kode 1
void luas_lingkaran(); //Prototype kode 2
void luas_persegi(); //Prototype kode 3

main(){
	int kode;
	cout<<"Kode 1 = Luas Segitiga\nKode 2 = Luas Lingkaran\nKode 3 = Luas Persegi\n\n";
	cout<<"Masukkan Kode ";cin>>kode;
	if(kode==1){
		luas_segitiga(); // Panggil Fungsi kode 1
	}else if(kode==2){
		luas_lingkaran(); // Panggil Fungsi kode 2
	}else if(kode==3){
		luas_persegi(); // Panggil Fungsi kode 3
	}else{
		cout<<"KODE SALAH\n";
			cout<<"Input Ulang Kode "; cin>>kode;
				if(kode==1){
					luas_segitiga(); // Panggil Fungsi kode 1
				}else if(kode==2){
					luas_lingkaran(); // Panggil Fungsi kode 2
				}else if(kode==3){
					luas_persegi(); // Panggil Fungsi kode 3
				}else{
					cout<<"ERROR *angry_react";
				}
	}
}


// Untuk Kode 1
void luas_segitiga(){
	float a,t,luas;
	cout<<"\nProgram Menghitung Luas Segitiga\n";
	cout<<"Alas   = ";cin>>a;
	cout<<"Tinggi = ";cin>>t;
	luas=a*t/2;
	cout<<"Luas   = "<<luas;
}

// Untuk Kode 2
void luas_lingkaran(){
	float PHI = 3.14;
	float jari, luas;
	cout<<"Masukan Jari-Jari Lingkaran : ";cin>>jari;
	luas =PHI*jari*jari;
	cout<<"Luas : "<<luas;
}

// Untuk Kode 3
void luas_persegi(){
	int sisi, luas;
	cout<<"Panjang Sisi: ";cin>>sisi;
	luas = sisi*sisi;
	cout<<"Luas Persegi = "<<luas;
}

