#include <iostream>
using namespace std;

struct biodata{
	char Nim[16], Nama[25], agama[10], Tanggal_lahir[5], tanggal_masuk_kuliah[5], jurusan[20];
};

struct alamat
{
	char jalan[20], kota[30], kode_pos[10];
};

struct tanggal
{
	char tanggal[15], bulan[10], tahun[10];
};

main (){
    biodata bdt;
    alamat tgl;
    tanggal a, b;

    cout<<"\t========================" << endl;
    cout<<"\t   Biodata Mahasiswa" << endl;
    cout<<"\t========================" << endl << endl;

    cout<<"  NIM 	     : ";
    cin.getline (bdt.Nim,50);

    cout<<"  NAMA 	     : ";
    cin.getline (bdt.Nama,25);

    cout<<"\n  ALAMAT" << endl;
    cout<<"     JALAN     : ";
        cin.getline (tgl.jalan,20);
    cout<<"     KOTA      : ";
        cin.getline (tgl.kota,30);
    cout<<"     KODE POS  : ";
        cin.getline (tgl.kode_pos,10);

    cout<<"\n  AGAMA	     : ";
        cin.getline (bdt.agama,10);

    cout<<"\n  TANGGAL LAHIR" << endl;
        cout<<"     TANGGAL   : ";
        cin.getline (a.tanggal,15);
        cout<<"     BULAN     : ";
        cin.getline (a.bulan,10);
        cout<<"     TAHUN     : ";
        cin.getline (a.tahun,10);

    cout<<"\n  MASUK KULIAH" << endl;
        cout<<"     TANGGAL   : ";
        cin.getline (b.tanggal,15);
        cout<<"     BULAN     : ";
        cin.getline (b.bulan,15);
        cout<<"     TAHUN     : ";
        cin.getline (b.tahun,15);

    cout<<"============================================" << endl;

    cout<<"\tHASIL" << endl << endl;

    cout<<"NIM 	: "<< bdt.Nim << endl;
    cout<<"NAMA 	: "<< bdt.Nama << endl << endl;
    cout<<"ALAMAT	: Kota "<< tgl.kota <<", "<< tgl.jalan <<", "<< tgl.kode_pos << endl;
    cout<<"AGAMA	: "<< bdt.agama << endl;
    cout<<"TANGGAL LAHIR" << endl;
        cout<<"  TANGGAL : "<< a.tanggal << endl;
        cout<<"  BULAN   : "<< a.bulan << endl;
        cout<<"  TAHUN   : "<< a.tahun << endl;
    cout<<"MASUK KULIAH" << endl;
        cout<<"  TANGGAL : "<< b.tanggal << endl;
        cout<<"  BULAN   : "<< b.bulan << endl;
        cout<<"  TAHUN   : "<< b.tahun << endl << endl;
}
