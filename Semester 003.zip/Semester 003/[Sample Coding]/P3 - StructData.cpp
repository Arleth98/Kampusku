#include <iostream>
using namespace std;

struct biodata{
	char Nim[16], Nama[25], agama[10], Tanggal_lahir[5], tanggal_masuk_kuliah[5], jurusan[20];
};

struct alamat
{
	char jalan[20], kota[30], kode_pos[10];
};

struct tanggal
{
	char tanggal[15], bulan[10], tahun[10];
};

main (){
    biodata bdt;
    alamat tgl;
    tanggal a, b;
	
    cout<<"\t========================" << endl;
    cout<<"\t   Biodata Mahasiswa" << endl;
    cout<<"\t========================" << endl << endl;

    cout<<"  NIM 	     : "; cin.getline (bdt.Nim,50);
    cout<<"  NAMA 	     : "; cin.getline (bdt.Nama,25);
    cout<<"  ALAMAT" << endl;
    cout<<"     JALAN     : "; cin.getline (tgl.jalan,20);
    cout<<"     KOTA      : "; cin.getline (tgl.kota,30);
    cout<<"     KODE POS  : "; cin.getline (tgl.kode_pos,10);
    cout<<"  AGAMA	     : "; cin.getline (bdt.agama,10);
    cout<<"  TANGGAL LAHIR" << endl;
        cout<<"     TANGGAL   : "; cin.getline (bdt.Tanggal_lahir,5);
        cout<<"     BULAN     : "; cin.getline (a.bulan,10);
        cout<<"     TAHUN     : "; cin.getline (a.tahun,10);
    cout<<"  MASUK KULIAH" << endl;
        cout<<"     TANGGAL   : "; cin.getline (bdt.tanggal_masuk_kuliah,5);
        cout<<"     BULAN     : "; cin.getline (b.bulan,15);
        cout<<"     TAHUN     : "; cin.getline (b.tahun,15);
    cout<<"  JURUSAN 	     : "; cin.getline (bdt.jurusan,20);

    cout<<"\n============================================" << endl;
    cout<<"\tHASIL" << endl << endl;

    cout<<"NIM           : "<< bdt.Nim << endl;
    cout<<"NAMA          : "<< bdt.Nama << endl;
    cout<<"ALAMAT        : Kota "<< tgl.kota <<", Jln. "<< tgl.jalan <<", "<< tgl.kode_pos << endl;
    cout<<"AGAMA         : "<< bdt.agama << endl;
    cout<<"LAHIR         : Tanggal "<< bdt.Tanggal_lahir <<", Bulan " << a.bulan <<", Tahun "<< a.tahun << endl;
    cout<<"MASUK KULIAH  : "<< "Tanggal "<< bdt.tanggal_masuk_kuliah <<", Bulan "<< b.bulan <<", Tahun "<< b.tahun << endl;
    cout<<"JURUSAN       : "<< bdt.jurusan << endl << endl;
}
