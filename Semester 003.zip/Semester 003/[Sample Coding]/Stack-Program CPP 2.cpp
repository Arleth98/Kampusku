#include <iostream>
#include <stdlib.h>
#include <conio.h>
#define MAX 5
using namespace std;

int top=-1, Stack[MAX];

void push()
{
	if(top == MAX-1)
	{
        cout<< "Stack sudah Penuh" << endl;
    }
	else
	{
	top++;
    cout<<"Masukan Data : ";
    cin>> Stack[top];
    cout << "Pada Index ke: " <<top;
    cout << " Data [" << Stack[top] << "] Telah Ditambah ! " << endl;
    }
};

void pop()
{
    if(top == -1)
	{
        cout << ">> Stack Kosong !" << endl;
    }
	else
	{
        cout << "\nData [" << Stack[top] << "] pada index ke '" << top << "' dalam Stack Diambil !" << endl;
        Stack[top--];
    }
};


void print()
{
    if (top == -1)
	{
 		cout << "Tumpukkan : Kosong"<< endl;
    }
    else {
        cout << "Tumpukkan : ";
             for (int i = top; i >= 0; i--){
              cout << Stack[i] << ", ";
             }
    }
};

int main()
{
	int choose;
	do{
		print();
		cout<<"\n1. Push"
			<<"\n2. Pop"
			<<"\n3. Exit"
			<<"\n\nChoose : "; cin>>choose;
		switch (choose){
			case 1 :
				push(); getch();
				break;
			case 2 :
				pop(); getch();
				break;
			case 3 :
				cout<<"keluar dari program"<<endl;
				getch();
				break;
			default:
				cout<<"pilihan tidak ada di daftar\nMasukan pilihan sesuai dengan daftar"<<endl;
				getch();
				break;
		}
		system("cls");
	}
	while(choose !=3);
}
