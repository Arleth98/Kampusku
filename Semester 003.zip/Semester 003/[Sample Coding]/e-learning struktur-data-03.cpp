#include <iostream>
#include <conio.h>
using namespace std;

struct Mahasiswa
{
  // NIM, Nama, Alamat, Agama, Tanggal Lahir, Tanggal Masuk Kuliah, Jurusan.
  char Nim[13], Nama[25], Alamat[40], Agama[9], tgllahir[15], Jurusan[20];
  short tglmasuk;
};

main()
{
  Mahasiswa Mhs;

  cout << "Nim : ";
  cin.getline(Mhs.Nim, 13);

  cout << "Nama :";
  cin.getline(Mhs.Nama, 25);

  cout << "Alamat :";
  cin.getline(Mhs.Alamat, 40);
  
  cout << "Agama :";
  cin.getline(Mhs.Agama, 9);

  cout << "Tanggal Lahir : ";
  cin.getline(Mhs.tgllahir, 15); 

  cout << "Tanggal Masuk Kuliah : ";
  cin>>Mhs.tglmasuk;
  
  cout << "Jurusan :";
  cin>>Mhs.Jurusan;

  cout << "\n\n\nNim : " << Mhs.Nim;
  cout << "\nNama : " << Mhs.Nama;
  cout << "\nAlamat : " << Mhs.Alamat;
  cout << "\nAgama : " << Mhs.Agama;
  cout << "\nTanggal Lahir : " << Mhs.tgllahir;
  cout << "\nTanggal Masuk Kuliah : " << Mhs.tglmasuk;
  cout << "\nJurusan : " << Mhs.Jurusan;
  getch();
}
